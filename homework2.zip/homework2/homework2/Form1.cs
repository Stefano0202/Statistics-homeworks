﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace homework2
{
    public partial class Form1 : Form
    {
        private Random _random = new Random(); // Random number generator
        private const int n = 30; // Servers
        private const int m = 50; // Attackers
        private const double p = 0.4; // Penetration probability

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            setUpCharts();
            runSimulation(n, p);
        }

        private void setUpCharts() // It initializes the charts
        {
            // The first chart for the attacks
            chart1.ChartAreas.Clear();
            var chartArea1 = new ChartArea();
            chartArea1.AxisX.Title = "Iterations (Servers)";
            chartArea1.AxisY.Title = "Penetration Count";
            chart1.ChartAreas.Add(chartArea1);
            chart1.Legends.Clear();

            // The second chart for absolute frequency distribution (midpoint)
            chart2.ChartAreas.Clear();
            var chartArea2 = new ChartArea();
            chartArea2.AxisX.Title = "Number of Servers Penetrated";
            chartArea2.AxisY.Title = "Absolute Frequency";
            chart2.ChartAreas.Add(chartArea2);
            chart2.Legends.Clear();
            chartArea2.AxisX.Minimum = -n; // The minimum
            chartArea2.AxisX.Maximum = n;  // The maximum
            chartArea2.AxisX.Interval = 5;

            // The third chart for absolute frequency distribution (at the end)
            chart3.ChartAreas.Clear();
            var chartArea3 = new ChartArea();
            chartArea3.AxisX.Title = "Number of Servers Penetrated";
            chartArea3.AxisY.Title = "Absolute Frequency";
            chart3.ChartAreas.Add(chartArea3);
            chart3.Legends.Clear();

            // The fourth chart for relative frequency distribution (in the middle)
            chart5.ChartAreas.Clear();
            var chartArea4 = new ChartArea();
            chartArea4.AxisX.Title = "Number of Servers Penetrated";
            chartArea4.AxisY.Title = "Relative Frequency";
            chart5.ChartAreas.Add(chartArea4);
            chart5.Legends.Clear();

            // The fifth chart for relative frequency distribution (at the end)
            chart4.ChartAreas.Clear();
            var chartArea5 = new ChartArea();
            chartArea5.AxisX.Title = "Number of Servers Penetrated";
            chartArea5.AxisY.Title = "Relative Frequency";
            chart4.ChartAreas.Add(chartArea5);
            chart4.Legends.Clear();
        }

        private void runSimulation(int n, double p)
        {
            chart1.Series.Clear();
            chart2.Series.Clear();
            chart3.Series.Clear(); 
            chart5.Series.Clear();
            chart4.Series.Clear();

            List<int> penCounts = new List<int>(new int[m]);  // Attackers' penetrations
            List<List<int>> attPenetrations = new List<List<int>>();

            // Loop through each server
            for (int server = 0; server < n; server++)
            {
                // Penetration progress for each attacker
                List<int> currPenetration = new List<int>(new int[m]);

                // Each attacker attempts to attack this specific server
                for (int att = 0; att < m; att++)
                {
                    bool penetrated = simulateAttacker(p);  // Simulate the attack
                    if (penetrated)
                    {
                        penCounts[att]++; // Increment the attacker's total count
                        currPenetration[att]++; // Increment for the current server
                    }
                    else
                    {
                        penCounts[att]--; // Decrement if not penetrated
                        currPenetration[att]--; // Decrement for the current server
                    }
                }

                // Update the penetration counts
                attPenetrations.Add(currPenetration);

                if (server <= n / 2)  // If we are before the middle
                    plotMidpointDistribution(penCounts); // Update second chart

                if(server == n/2)  // Now we are in the middle and we can plot the relative distr.
                    plotRelativeMidpointDistribution(penCounts);
            }

            // Plot results for each attacker
            for (int att = 0; att < m; att++)
            {
                plotAttacker(att, attPenetrations);
            }

            // Plot the final absolute frequency distribution in chart3
            plotFrequencyDistribution(penCounts);

            // Plot relative frequency distributions
            plotRelativeFrequencyDistribution(penCounts);
        }

        private bool simulateAttacker(double p)
        {
            return _random.NextDouble() < p; // Return true if penetrated
        }

        private void plotAttacker(int attIndex, List<List<int>> attPenetrations)
        {
            var series = new Series
            {
                ChartType = SeriesChartType.Line,
                Color = getRandomColor(),
                BorderWidth = 2
            };

            int currCount = 0; // Cumulative count for the attacker

            // Plot penetration progress
            for (int server = 0; server < attPenetrations.Count; server++)
            {
             
                if (attPenetrations[server][attIndex] > 0)
                {
                    currCount++; // Successful penetration
                }
                else
                {
                    currCount--; // Failed penetration
                }

                series.Points.AddXY(server + 1, currCount);
            }

            chart1.Series.Add(series); // Add the series for this attacker to the chart
        }

        private void plotFrequencyDistribution(List<int> penCounts)
        {
            var freqMap = new Dictionary<int, int>();
            double recMean = 0;
            double recVariance = 0;
            int totalCounts = penCounts.Count; 

            // Populate frequency map
            foreach (var count in penCounts)
            {
                if (freqMap.ContainsKey(count))
                    freqMap[count]++;
                else
                    freqMap[count] = 1;
            }

            int minCount = penCounts.Min();
            int maxCount = penCounts.Max();

            var freqSeries = new Series
            {
                ChartType = SeriesChartType.Column,
                Color = Color.Blue,
                IsValueShownAsLabel = true
            };

            for (int i = minCount; i <= maxCount; i++)
            {
                int freq = freqMap.ContainsKey(i) ? freqMap[i] : 0;
                freqSeries.Points.AddXY(i, freq);

                // Update recursive mean
                int n = freqSeries.Points.Count; // Number of values considered
                recMean = recMean + (freq - recMean) / n;

                // Update recursive variance
                double x_n = freq; // Current frequency for variance calculation
                recVariance = recVariance + (x_n * x_n - recMean * recMean - recVariance) / n;
            }

            chart3.Series.Add(freqSeries);

            chart3.Titles.Clear(); // Clear previous titles
            chart3.Titles.Add($"Absolute Frequency Distribution\nMean: {recMean:F2}, Variance: {recVariance:F2}");
        }

        private void plotMidpointDistribution(List<int> penCounts)
        {
            chart2.Series.Clear();
            var series = new Series
            {
                ChartType = SeriesChartType.Column,
                Color = Color.Green,
                IsValueShownAsLabel = true
            };

            var freqMap = new Dictionary<int, int>();
            double recMean = 0;
            double recVariance = 0;
            int totalCounts = penCounts.Count;

            foreach (var count in penCounts)
            {
                if (freqMap.ContainsKey(count))
                    freqMap[count]++;
                else
                    freqMap[count] = 1;
            }

            int minCount = penCounts.Min();
            int maxCount = penCounts.Max();

            for (int i = minCount; i <= maxCount; i++)
            {
                int freq = freqMap.ContainsKey(i) ? freqMap[i] : 0;
                series.Points.AddXY(i, freq);

                // Update recursive mean
                int n = series.Points.Count; // Number of values considered
                recMean = recMean + (freq- recMean) / n;

                // Update recursive variance
                double x_n = freq; // Current frequency for variance calculation
                recVariance = recVariance + (x_n * x_n - recMean * recMean - recVariance) / n;
            }

            chart2.Series.Add(series);

            chart2.Titles.Clear(); // Clear previous titles
            chart2.Titles.Add($"Midpoint Distribution\nMean: {recMean:F2}, Variance: {recVariance:F2}");
        }
        private void plotRelativeFrequencyDistribution(List<int> penCounts)
        {
            var freqMap = new Dictionary<int, int>();

            // Count frequencies of penetration counts
            foreach (var count in penCounts)
            {
                if (freqMap.ContainsKey(count))
                    freqMap[count]++;
                else
                    freqMap[count] = 1;
            }

            // Total number of attacks
            int totalCounts = penCounts.Count;

            // Range for X axis
            int minCount = penCounts.Min();
            int maxCount = penCounts.Max();

            var relativeSeries = new Series
            {
                ChartType = SeriesChartType.Column,
                Color = Color.Red,
                IsValueShownAsLabel = true
            };

            for (int i = minCount; i <= maxCount; i++)
            {
                if (freqMap.ContainsKey(i))
                {
                    double relFrequency = (double)freqMap[i] / totalCounts; // Calculate relative frequency
                    relativeSeries.Points.AddXY(i, relFrequency);
                }
                else
                {
                    relativeSeries.Points.AddXY(i, 0); // Zero for counts not present
                }
            }

            chart4.Series.Add(relativeSeries); // Add the relative frequency series
        }

        private void plotRelativeMidpointDistribution(List<int> penCounts)
        {
            // Clear previous series and create a new one for the midpoint distribution
            chart5.Series.Clear();
            var series = new Series
            {
                ChartType = SeriesChartType.Column,
                Color = Color.Orange,
                IsValueShownAsLabel = true
            };

            // Count the frequency of successful penetrations
            var freqMap = new Dictionary<int, int>();

            foreach (var count in penCounts)
            {
                if (freqMap.ContainsKey(count))
                    freqMap[count]++;
                else
                    freqMap[count] = 1;
            }

            // Total number of attacks
            int totalCounts = penCounts.Count;

            // Range for X axis
            int minCount = penCounts.Min();
            int maxCount = penCounts.Max();

            // Add relative frequencies to the serie
            for (int i = minCount; i <= maxCount; i++)
            {
                if (freqMap.ContainsKey(i))
                {
                    double relFrequency = (double)freqMap[i] / totalCounts; // Calculate relative frequency
                    series.Points.AddXY(i, relFrequency);
                }
                else
                {
                    series.Points.AddXY(i, 0); // Zero for counts not present
                }
            }

            chart5.Series.Add(series); // Add the series
        }

        private Color getRandomColor() // Random color
        {
            return Color.FromArgb(
                _random.Next(256),
                _random.Next(256),
                _random.Next(256)
            );
        }
    }
}