﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace homework1
{
    public partial class Form1 : Form // Entry point
    {
        private Random _random = new Random(); // Random number generator
        private const int n = 30; // Servers
        private const int m = 50; // Attackers
        private const double p = 0.7; // Penetration probability

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Set up the charts
            setUpCharts();

            // Run simulation
            runSimulation(n, p);
        }

        private void setUpCharts() // Method that initializes the charts
        {
            // The first chart for the attacks
            chart1.ChartAreas.Clear();
            var chartArea1 = new ChartArea();
            chartArea1.AxisX.Minimum = 1; // X-axys begin from 1
            chartArea1.AxisY.Minimum = 0; // Y-axys from 0
            chart1.ChartAreas.Add(chartArea1);
            chart1.Legends.Clear(); // No legend

            // The same
            chart2.ChartAreas.Clear();
            var chartArea2 = new ChartArea();
            chartArea2.AxisX.Title = "Number of Servers Penetrated";
            chartArea2.AxisY.Title = "Frequency";
            chart2.ChartAreas.Add(chartArea2);
            chart2.Legends.Clear();
            chartArea2.AxisX.Minimum = 0;
            chartArea2.AxisX.Maximum = n;
        }

        private void runSimulation(int n, double p)
        {
            chart1.Series.Clear(); // Clear chart1
            chart2.Series.Clear(); // Clear chart2

            List<int> penCounts = new List<int>(); // To save penetration counts

            // Loop for each attacker
            for (int att = 0; att < m; att++)
            {
                // To save the penetration counts for the current attacker
                List<bool> penRes = new List<bool>();

                int penetrationCount = simulateAttacker(n, p, penRes); // The result of penetration
                penCounts.Add(penetrationCount); // Insert the count of penetrated servers

                // Plot the results
                plotAttacker(att, n, penRes);
            }

            // Plot the frequency distribution
            plotFrequencyDistribution(penCounts);
        }

        private int simulateAttacker(int n, double p, List<bool> penRes) // Method to simulate an attack
        {
            penRes.Clear(); // Clear the old results
            int count = 0; 

            for (int j = 0; j < n; j++) // Loop for each server
            {
                bool penetrated = _random.NextDouble() < p; // Compare a random number with p
                penRes.Add(penetrated); // Store the result
                if (penetrated) count++; // Increment count in case of success
            }
            return count; // Return the penetrated servers
        }

        private void plotAttacker(int att, int n, List<bool> penRes) // Method to plot an attacker's results
        {
            var series = new Series
            {
                ChartType = SeriesChartType.Line, // Line
                Color = getRandomColor(), // Random color
                BorderWidth = 2 // Width
            };

            int freq = 0;

            for (int i = 0; i < n; i++) // Loop for each server
            {
                // If the attacker penetrated the server, increment the frequency
                if (penRes[i])
                {
                    freq++;
                }

                // Add the frequency level to the series
                series.Points.AddXY(i + 1, freq);
            }

            chart1.Series.Add(series); // Add the series to the chart
        }

        private void plotFrequencyDistribution(List<int> penCounts) // Method to plot frequency distribution
        {
            var frequencyMap = new Dictionary<int, int>();

            // Count frequencies of penetration counts
            foreach (var count in penCounts)
            {
                if (frequencyMap.ContainsKey(count))
                    frequencyMap[count]++;
                else
                    frequencyMap[count] = 1;
            }

            for (int i = 0; i <= n; i++)
            {
                if (!frequencyMap.ContainsKey(i))
                    frequencyMap[i] = 0; // Initialize frequency to 0 if not present
            }

            var freqSeries = new Series
            {
                ChartType = SeriesChartType.Column,
                Color = Color.Blue,
                IsValueShownAsLabel = true
            };

            // Add counts to the frequency series
            foreach (var entry in frequencyMap.OrderBy(k => k.Key))
            {
                freqSeries.Points.AddXY(entry.Key, entry.Value);
            }

            chart2.Series.Add(freqSeries); // Add the frequency series to the second chart
        }

        private Color getRandomColor() // Method to generate a random color
        {
            return Color.FromArgb(
                _random.Next(256),
                _random.Next(256),
                _random.Next(256)
            );
        }

        // Empty method for chart1 Click event
        private void chart1_Click(object sender, EventArgs e)
        {
            // Intentionally left empty
        }
    }
}
