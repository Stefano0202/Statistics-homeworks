﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace homework1 {
public partial class Form1 : Form // The entry point of the program
{
    private Random _random = new Random(); // A random number generator

    public Form1()
    {
        InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e) // Actions that will be at load
    {
        // It allows to set the origin of charts in (0,0)
        setUpCharts();

        // Parameters needed
        int n = 30; // Number of servers
        int m = 50; // Number of attackers
        double p = 0.7; // Probability of penetration

        // Run simulation
        runSimulation(n, m, p);
    }

    private void setUpCharts() // Method to initialize the charts
    {
        // chart1
        chart1.ChartAreas.Clear(); // Clear any chart
        var chartArea1 = new ChartArea(); // Create a new chart area
        chartArea1.AxisX.Minimum = 0; // Set the minimum value for the X to 0
        chartArea1.AxisY.Minimum = 0; // Set the minimum value for the Y to 0
        chart1.ChartAreas.Add(chartArea1); // Add it to chart1

        // The same
        histogramChart.ChartAreas.Clear(); 
        var chartArea2 = new ChartArea(); 
        chartArea2.AxisX.Minimum = 0; 
        chartArea2.AxisY.Minimum = 0; 
        histogramChart.ChartAreas.Add(chartArea2);
    }

    private void runSimulation(int n, int m, double p) // Method to run the simulation
    {
        chart1.Series.Clear(); // Clear any existing data in chart1
        histogramChart.Series.Clear(); // Clear any existing data in histogramChart
        var penetrationCounts = new List<int>(); // List to store the number of penetrations for each attacker

        // Simulate each attacker
        for (int i = 0; i < m; i++) // Loop through the number of attackers
        {
            int penetrationCount = simulateAttacker(n, p); // Simulate an attack
            penetrationCounts.Add(penetrationCount); // Add the count to the list
            plotAttacker(i, n, penetrationCount); // Plot the results on the chart
        }

        plotHistogram(penetrationCounts, n); // Plot the histogram of penetration counts
    }

    private int simulateAttacker(int n, double p) // Method to simulate an attack
    {
        int count = 0; // Initialize count
        for (int j = 0; j < n; j++) // Loop through the number of servers
        {
            // Check if the attacker penetrates the server 
            if (_random.NextDouble() < p) // Compare a random number with penetration probability
            {
                count++; // Increment the count if penetration is successful
            }
        }
        return count; // Return the number of penetrated servers
    }

    private Color getRandomColor() // Method to generate a random color
    {
        return Color.FromArgb(
            _random.Next(256),
            _random.Next(256),
            _random.Next(256)
        );
    }

    private void plotAttacker(int att, int n, int penCount) // Method to plot an attacker's results
    {
        // Create a new series for the attacker
        var series = new Series
        {
            Name = $"Attacker {att + 1}", // Name of the series
            ChartType = SeriesChartType.StepLine, // Set the chart type to StepLine
            Color = getRandomColor(), // Assign a random color to the attacker
            BorderWidth = 2 // Width of the line
        };

        int currentPenetrationLevel = 0; // Initialize the current penetration level

        // Plot the penetration levels
        for (int j = 0; j < n; j++) // Loop through the number of servers
        {
            if (j < penCount) // Check if this server was penetrated
            {
                currentPenetrationLevel++; // Increment the current penetration level (the line grows up)
            }
            series.Points.AddXY(j, currentPenetrationLevel); // Add the level to the series
        }

        series.Points.AddXY(n, currentPenetrationLevel); // Maintain the last level

        chart1.Series.Add(series); // Add the series to the chart
    }

    private void plotHistogram(List<int> penCounts, int n) // Method to plot the histogram of penetration counts
    {
        var histogram = new int[n + 1]; // Array to count penetrations for each level

        foreach (var count in penCounts) // Loop through each attacker's penetration count
        {
            histogram[count]++; // Increment the histogram count for this penetration level
        }

        // Create new series for the histogram
        var histSeries = new Series
        {
            Name = "Penetration Frequency", // Name of the series
            ChartType = SeriesChartType.Column, // Chart type to Column
            Color = Color.Red, // Color of the columns
            IsValueShownAsLabel = true // Show the value as a label
        };

        for (int i = 0; i < histogram.Length; i++) // Loop through the histogram data
        {
            histSeries.Points.AddXY(i, histogram[i]); // Add each count to the histogram series
        }

        histogramChart.Series.Add(histSeries); // Add the histogram series to the histogram chart

        // Configure axis titles
        histogramChart.ChartAreas[0].AxisX.Title = "Number of Servers Penetrated"; 
        histogramChart.ChartAreas[0].AxisY.Title = "Frequency";
        histogramChart.Titles.Clear(); // Clear any existing titles
        histogramChart.Titles.Add($"Distribution of Penetrations (n={n}, m={penCounts.Count})"); // Title of the histogram
    }
}
}
